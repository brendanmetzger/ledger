(function (domain) {
  // append a new script to the document.

}(window.domain));
